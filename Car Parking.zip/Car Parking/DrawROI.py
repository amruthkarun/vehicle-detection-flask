import cv2
import numpy as np
import os


def draw_shape(event,x,y,flags,params):
        global ix,iy,drawing
        if event==cv2.EVENT_LBUTTONDOWN:
                drawing=True
                (ix,iy)=x,y
        elif event==cv2.EVENT_MOUSEMOVE:
                pass
        elif event==cv2.EVENT_LBUTTONUP:
               drawing = False 
               if mode ==True:
                    cv2.rectangle(img,(ix,iy),(x,y),(0,255,0),1)
                    rectangle.extend((ix,iy,x,y))
                    print(rectangle)
                    f=open('out.txt','a')
                    f.write(str(ix)+" "+str(iy)+" "+str(x)+" "+str(y)+'\n')


def main():
        global mode,img
        windowname ="drawing"
        cap = cv2.VideoCapture('1.mp4')
        success, img =cap.read()
        cv2.namedWindow(windowname)
        drawing =False
        mode =True
        rectangle=[]
        i=0
        (ix,iy)=(-1,-1)
        cv2.setMouseCallback(windowname,draw_shape)               
        l=len(rectangle)/4
        clone = img.copy()
        while (True):
           cv2.imshow(windowname, img)
           k= cv2.waitKey(1)
           if k==ord('s'):
                img= clone.copy() 
                if os.path.exists("out.txt"):
                 os.remove("out.txt")
           elif k== 27:
                 if os.path.exists("out.txt"):
                  os.remove("out.txt")
                 break
        cv2.destroyAllWindows()
if __name__=="__main__":
        main()


