﻿###
 # @file        OpenVINODetect.py
 # @brief       This python code is used for Person/face detection using OpenVINO
 #              ALL RIGHTS RESERVED.
 ###

#!/usr/bin/env python

from __future__ import print_function
import sys
import os
import cv2
import numpy as np
import time
import math
import logging as log
import json
from collections import namedtuple
from openvino.inference_engine import IENetwork, IEPlugin, IENetLayer
import pandas as pd
model_xml = ""
input_vid = ""
cpu_extension = ""
prob_threshold = ""
#Path of the directory where OpenVINO is installed
OPENVINO_HOME = "/opt/intel/computer_vision_sdk_2018.4.420"

def CheckIntersectionArea(roi, bbox):  
    dx = min(roi.xmax, bbox.xmax) - max(roi.xmin, bbox.xmin)
    dy = min(roi.ymax, bbox.ymax) - max(roi.ymin, bbox.ymin)
    if (dx >= 0) and (dy >= 0):
        return dx*dy
    else:
       return 0

# Function for initilising model file and input
def init():
    global model_xml
    global model_age_gender_xml
    global model_head_pose_xml
    global model_emotion_xml
    global input_vid 
    global cpu_extension 
    global prob_threshold
    global OPENVINO_HOME
    input_vid = "./2.mp4"
    model_xml = OPENVINO_HOME +"/deployment_tools/intel_models/face-detection-adas-0001/FP32/face-detection-adas-0001.xml"
    model_age_gender_xml = OPENVINO_HOME + "/deployment_tools/intel_models/age-gender-recognition-retail-0013/FP32/age-gender-recognition-retail-0013.xml"
    #Path to cpu extension library
    cpu_extension = OPENVINO_HOME +"/inference_engine/lib/ubuntu_16.04/intel64/libcpu_extension_sse4.so"
    prob_threshold = 0.5

# Function for Person Detection
def person_detection():
     #Path to person detection model file
     model_xml = OPENVINO_HOME +"/deployment_tools/intel_models/face-detection-adas-0001/FP32/face-detection-adas-0001.xml"
     #Path to intermediate .bin file of person detection model
     model_bin = os.path.splitext(model_xml)[0] + ".bin"
     # Plugin initialization for specified device and load extensions library
     #print("Initializing plugin for CPU device...")
     plugin = IEPlugin(device="CPU", plugin_dirs=None)
     plugin.add_cpu_extension(cpu_extension)
     
     # Read IR of Person Detection model
     #print("Reading IR of Person Detection model.....")
     net_person_detection = IENetwork.from_ir(model=model_xml, weights=model_bin)
    
     supported_layers = plugin.get_supported_layers(net_person_detection)
     not_supported_layers = [l for l in net_person_detection.layers.keys() if l not in supported_layers]
     
     if (len(not_supported_layers)) != 0:
        log.error("Following layers are not supported by the plugin for specified device {}:\n {}".
                    format(plugin.device, ', '.join(not_supported_layers)))
        log.error("Please try to specify cpu extensions library path ")
        sys.exit(1)
    
     assert len(net_person_detection.inputs.keys()) == 1, "Sample supports only single input topologies"
     assert len(net_person_detection.outputs) == 1, "Sample supports only single output topologies"
     input_person_detection_blob = next(iter(net_person_detection.inputs))
     
     out_person_blob = next(iter(net_person_detection.outputs))
     
     #print("Loading IR to the plugin...")
     exec_net_person_detection = plugin.load(network=net_person_detection, num_requests=2)
  
     # Read and pre-process input frame
     n, c, h, w = net_person_detection.inputs[input_person_detection_blob].shape
     del net_person_detection
   
     
     cap = cv2.VideoCapture(input_vid)
    
     cur_request_id = 0
     next_request_id = 0
 
     #print("Starting inference ...")
     i = 0
    
     while cap.isOpened():
        ret, frame = cap.read()
        
        if not ret:
            break     
        initial_w = cap.get(3)
        initial_h = cap.get(4)

        in_frame_person_detection = cv2.resize(frame, (w, h))
        in_frame_person_detection = in_frame_person_detection.transpose((2, 0, 1))  # Change data layout from HWC to CHW
        in_frame_person_detection = in_frame_person_detection.reshape((n, c, h, w))

        #Start execution
        exec_net_person_detection.start_async(request_id=next_request_id, inputs={input_person_detection_blob: in_frame_person_detection})
        if exec_net_person_detection.requests[cur_request_id].wait(-1) == 0:

            # Parse person detection results of the current request
            res_person_detection = exec_net_person_detection.requests[cur_request_id].outputs[out_person_blob]
            xTopLeft = []
            yTopLeft = []
            xBotRight = []
            yBotRight = []
            for person in res_person_detection[0][0]:

                # Detect person when probability is more than specified threshold of 0.5
                if person[2] > prob_threshold:
                    # Bounding box co-ordinate output of person detection
                    xmin = int(person[3] * initial_w)
                    ymin = int(person[4] * initial_h)
                    xmax = int(person[5] * initial_w)
                    ymax = int(person[6] * initial_h)
                    xTopLeft.append(xmin)
                    xBotRight.append(xmax)
                    yTopLeft.append(ymin)
                    yBotRight.append(ymax)
                    class_id = int(person[1])
            # Draw performance stats
         
       
        rectROI_coord = []
   
        Rectangle = namedtuple('Rectangle', 'xmin ymin xmax ymax')
        
        flag = 0   
        k=0
        while(k < len(xTopLeft)):
          rectBBox_coord = Rectangle(xTopLeft[k],yTopLeft[k],xBotRight[k],yBotRight[k])
         
          l = 0
          while(l<len(message["boundingBox"])):
           x0 = int(message["boundingBox"][l]["x1"])
           y0 = int(message["boundingBox"][l]["y1"])
           x1 = int(message["boundingBox"][l]["x2"])
           y1 = int(message["boundingBox"][l]["y2"])
           rectROI_coord.append(Rectangle(x0,y0,x1,y1))
           cv2.rectangle(frame,(x0,y0),(x1,y1), (150,167,0), 2)
           #Check the intersection with RoI
           if(CheckIntersectionArea(rectROI_coord[l],rectBBox_coord)>0 ):
             cv2.rectangle(frame,(xTopLeft[k],yTopLeft[k]),(xBotRight[k],yBotRight[k]), (0,255,0), 2)
             # Set flag = 1 if there is intersection between bounding box coordinate and ROI
             flag=1
           l += 1
          k += 1
         
        i = i+1 
        render_start = time.time()        
        cv2.imshow("Detection Results", frame)
        key = cv2.waitKey(1)
        if key == 27:
            break
        
        cur_request_id, next_request_id = next_request_id, cur_request_id
     end = time.time()
    
     cv2.destroyAllWindows()
     del exec_net_person_detection
     del plugin



# Main function for Person/Face Detection
def main():
  
    global model_xml
    global model_age_gender_xml
    #global input_vid
    global cpu_extension
    global prob_threshold
    global message
    global detectionObj
    # Function for initialisation of model files for detection
    init()
    # Loading IOTHubMessage json file as input to python script
    with open('roiBox.json') as f:
     message=json.load(f)
    person_detection()
if __name__ == '__main__':
    sys.exit(main() or 0)
