from tkinter import *
from PIL import Image, ImageTk
# image for background was sized 600x400
# image for canvas was sized 100x100

root = Tk()
image = Image.open("max.jpg")
photo = ImageTk.PhotoImage(image)
#background_image=PhotoImage(file="g.gif")
background_label = Label(root, image=photo)
background_label.place(x=0, y=0, relwidth=1, relheight=1)
background_label.image=photo
root.wm_geometry("600x400+20+40")

canvas = Canvas(root, width=100, height=140)
canvas.grid(row = 0, column = 0)
photo = PhotoImage(file="g.gif")
#canvas.create_image(0, 0, anchor = NW, image=photo)


root.mainloop()
